html_template = '''
        <div class="card">
                <div class="card-body border-bottom border-bottom-dashed p-4">
                    <div class="row">
                        <span style="text-align: center;">
                            <h4>Adira Internaonal Chef Academy <br>Practical Test Report</h4>
                        </span>
                    </div>
                    <!--end row-->
                </div>
                <div class="row card-body p-4">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            {}
                        </table>
                    </div>
                        <!--end col-->
                </div>
                <div class="card-body p-4">
                    <div>
                        <label for="billingName" class="text-uppercase fw-semibold">Performance Evaluaon:</label>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-row table-responsive">
                            <thead class="align-middle ">
                                <tr class="table-active">
                                    <th scope="col">
                                        Evaluation Criteria
                                    </th>
                                    <th scope="col" class="text-end" style="width: 100px;">Excellent</th>
                                    <th scope="col" class="text-end" style="width: 100px;">Good</th>
                                    <th scope="col" class="text-end" style="width: 100px;">Average</th>
                                    <th scope="col" class="text-end" style="width: 100px;">Below Average</th>
                                </tr>

                            </thead>
                            <tbody>
                                <tr class="">
                                    <td>South Cuisine/ Parotta</td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="parotta" value="excellent" required/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="parotta" value="good"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="parotta" value="average"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="parotta" value="below-average"/>
                                    </td>
                                </tr>
                                <tr class="">
                                    <td>Time Management</td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="time-management" value="excellent" required/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="time-management" value="good"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="time-management" value="average"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="time-management" value="below-average"/>
                                    </td>
                                </tr>
                                <tr class="">
                                    <td>Communication</td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="communication" value="excellent" required/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="communication" value="good"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="communication" value="average"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="communication" value="below-average"/>
                                    </td>
                                </tr>
                                <tr class="">
                                    <td>Attitude</td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="attitude" value="excellent" required/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="attitude" value="good"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="attitude" value="average"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="attitude" value="below-average"/>
                                    </td>
                                </tr>
                                <tr class="">
                                    <td>Personality</td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="personality" value="excellent" required/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="personality" value="good"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="personality" value="average"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="personality" value="below-average"/>
                                    </td>
                                </tr>
                                <tr class="">
                                    <td>Sanitizing</td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="sanitizing" value="excellent" required/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="sanitizing" value="good"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="sanitizing" value="average"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="sanitizing" value="below-average"/>
                                    </td>
                                </tr>
                                <tr class="">
                                    <td>Health</td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="health" value="excellent" required/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="health" value="good"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="health" value="average"/>
                                    </td>
                                    <td class="text-center" style="width:100px;">
                                        <input type="radio" name="health" value="below-average"/>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5"></td>
                                </tr>
                                <tr>
                                    <td>Any Accident</td>
                                    <td class="text-center">Yes <input type="radio" name="any-accident" value="yes" required/></td>
                                    <td class="text-center">No <input type="radio" name="any-accident" value="no"/></td>
                                    <td colspan="2"></td>
                                </tr>
                            </tbody>
                        </table>
                        <!--end table-->
                    </div>
                    <div class="row mt-3">
                        <div class="col-lg-12 mt-2">
                            <hr>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->
                    <div class="mt-3">
                        <label for="exampleFormControlTextarea1"
                            class="form-label text-muted text-uppercase fw-semibold">Comments</label>
                        <textarea class="form-control alert alert-info" name="comments" placeholder="Comments" rows="2"
                            required></textarea>
                    </div>
                </div>
            </form>
        </div>
        '''