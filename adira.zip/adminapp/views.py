from django.shortcuts import render, redirect
from django.views import View
from candidatetest.models import CandidateTestModel
from django.http import HttpResponse, JsonResponse
import fitz, os, uuid, time
from adira import settings
from io import BytesIO
from django.core.files.uploadedfile import InMemoryUploadedFile

class AdminDashboard(View):
    template_name = 'applied-candidate-list.html'
    def get(self, request):
        candidates = CandidateTestModel.objects.all()
        datas = {'candidates': candidates}
        return render(request, self.template_name, context=datas)

class CandidateReportView(View):
    template_name = 'candidate-report.html'
    def get(self, request, id):
        try:
            candidate = CandidateTestModel.objects.get(id=id)
            candidate_report = candidate.report
            if candidate_report is None or not isinstance(candidate_report, dict):
                candidate_report = {}
            datas = {
                'candidate': candidate,
                **candidate_report,
                'report_status': ['excellent', 'good', 'average', 'below-average'],
            }
        except:
            datas = {}
        return render(request, self.template_name, context=datas)
    
    def post(self, request, id):
        try:
            candidate = CandidateTestModel.objects.get(id=id)
            report_datas = {
                'parotta': request.POST.get('parotta'),
                'timemanagement': request.POST.get('time-management'),
                'communication': request.POST.get('communication'),
                'attitude': request.POST.get('attitude'),
                'personality': request.POST.get('personality'),
                'sanitizing': request.POST.get('sanitizing'),
                'health': request.POST.get('health'),
                'anyaccident': request.POST.get('any-accident'),
                'comments': request.POST.get('comments')
            }
            candidate.report = report_datas
            candidate.save()
            response_data = {'status': 'success', 'msg': f'{candidate.candidate_name}, Report Saved'}
        except Exception as e:
            response_data = {'status': 'error', 'msg': f'{e}'}
        
        return JsonResponse(response_data)