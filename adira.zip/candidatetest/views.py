from django.shortcuts import render, redirect
from django.views import View
from candidatetest import models
from django.http import JsonResponse
import datetime, time
import fitz, os, uuid
from adira import settings
from io import BytesIO
from django.core.files.uploadedfile import InMemoryUploadedFile

class CandidateTestView(View):
    template_name = 'candidate-test-form.html'
    def get(self, request):
        category = models.CandidateTestCategoryModel.objects.all()
        book_time = {'morning': ['10:30 am', '10:45 am', '11:00 am', '11:15 am', '11:30 am', '11:45 am'],
                     'afternoon': ['12:00 pm', '12:15 pm', '12:30 pm', '12:45 pm', '01:00 pm', '01:15 pm', 
                                   '01:30 pm', '01:45 pm', '02:00 pm', '02:15 pm', '02:30 pm', '02:45 pm', 
                                   '03:00 pm', '03:15 pm', '03:30 pm', '03:45 pm'],
                     'evening': ['04:00 pm']}
        datas = {
            'category': category,
            'book_time': book_time,
        }
        return render(request, self.template_name, context=datas)

class CandidateTestFormView(View):
    def post(self, request):
        category = request.POST.get('category')
        book_date = request.POST.get('book-date')
        book_time = request.POST.get('book-time')
        candidate_name = request.POST.get('candidate-name')
        dob = request.POST.get('dob')
        passport_no = request.POST.get('passport-no')
        contact_number = request.POST.get('contact-number')
        whatsapp_number = request.POST.get('whatsapp-number')
        email = request.POST.get('email')
        agent_code = request.POST.get('agent-code')
        
        try:
            try:
                category = models.CandidateTestCategoryModel.objects.get(id=category)
            except:
                response_data = {'status': 'error', 'msg': 'Category Not Found'}
                return JsonResponse(response_data)
            
            try:
                book_date = datetime.datetime.strptime(book_date, '%Y-%m-%d').date()
            except:
                response_data = {'status': 'error', 'msg': 'Please Check Booking Date'}
                return JsonResponse(response_data)
            
            try:
                book_time = datetime.datetime.strptime(book_time, '%H:%M %p')
            except:
                response_data = {'status': 'error', 'msg': 'Please Check Booking Time'}
                return JsonResponse(response_data)
            
            try:
                dob = datetime.datetime.strptime(dob, '%Y-%m-%d').date()
            except:
                response_data = {'status': 'error', 'msg': 'Please Enter Date Of Birth'}
                return JsonResponse(response_data)
            
            if not str(candidate_name).strip():
                response_data = {'status': 'error', 'msg': 'Please Enter Candidate Name'}
                return JsonResponse(response_data)
            
            if not str(passport_no).strip():
                response_data = {'status': 'error', 'msg': 'Please Enter Passport Number'}
                return JsonResponse(response_data)
            
            if not str(contact_number).strip():
                response_data = {'status': 'error', 'msg': 'Please Enter Contact Number'}
                return JsonResponse(response_data)
            
            if not str(whatsapp_number).strip():
                response_data = {'status': 'error', 'msg': 'Please Enter Whatsapp Number'}
                return JsonResponse(response_data)
            
            
            certificate_template = os.path.join(settings.BASE_DIR, 'certificates', 
                                                "adira-certificate-template.pdf")
            
            pdf = fitz.open(certificate_template)
            page = pdf[0]
            candidate_name = str(candidate_name).strip().title()
            
            body1 = f"Passport No. {passport_no} has successfully Completed the test on {book_date}"
            body2 = f"and fulfilled the required standards for the role of {category.name.title()}"
            
            name_page_width = page.rect.width
            name_width = fitz.get_text_length(candidate_name, fontsize=20, fontname="helv")
            width = (name_page_width - name_width) / 2
            position=(width, 290)
            page.insert_text(position, candidate_name, fontsize=20, fontname="helv")
            
            # body1
            body_page_width = page.rect.width
            body_width = fitz.get_text_length(body1, fontsize=18, fontname="helv")
            width = (body_page_width - body_width) / 2
            position=(width, 340)
            page.insert_text(position, body1, fontsize=18, fontname="helv")

            # body2
            body_page_width = page.rect.width
            body_width = fitz.get_text_length(body2, fontsize=18, fontname="helv")
            width = (body_page_width - body_width) / 2
            position=(width, 370)

            page.insert_text(position, body2, fontsize=18, fontname="helv")

            filename = f'{candidate_name}.pdf'
            certificate_pdf = InMemoryUploadedFile(
                                    file=BytesIO(pdf.write()),
                                    field_name=None,
                                    name=filename,
                                    content_type='application/pdf',
                                    size=len(pdf),
                                    charset=None
                                )
            
            new_candidate = models.CandidateTestModel(category=category,
                                    book_date=book_date,
                                    book_time=book_time,
                                    candidate_name=candidate_name,
                                    date_of_birth=dob,
                                    passport_no=passport_no,
                                    contact_number=contact_number,
                                    whatsapp_number=whatsapp_number,
                                    email=email,
                                    agent_code=agent_code,
                                    certificate=certificate_pdf)
            new_candidate.save()
            
            response_data = {'status': 'success', 
                             'msg': f'{str(candidate_name).title()}, Thanks for Booking. Our Team Contact You'}
            return JsonResponse(response_data)
        except Exception as e:
            response_data = {'status': 'error', 'msg': f'Error: {e}'}
            return JsonResponse(response_data)